# Python package template

To launch:  
Put the package in the source folder of your catkin_ws.
Build the package with catkin build and source the workspace.  
Launch with:
	$ roslaunch python_package_template python_package_template.launch
	


