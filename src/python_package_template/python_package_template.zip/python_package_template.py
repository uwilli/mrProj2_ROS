#!/usr/bin/env python


import roslib
import rospy


if __name__=="__main__":
    rospy.init_node('python_package_template')
    rospy.loginfo("Hello world python_package_template")
